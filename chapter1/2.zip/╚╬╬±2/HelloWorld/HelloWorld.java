/**
 * 第一个Java程序
 * @author andy
 * @version 1.0
 */
public class HelloWorld {
    /**
     * 程序入口
     * @param args 命令行参数
     */
    public static void main(String[] args) {
        System.out.println("你好世界！");
    }
}