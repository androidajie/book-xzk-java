import java.util.Scanner;

/**
 * 变量示例
 */
public class VariablesDemo {
    public static void main(String[] args) {
        int age = 18;           // 年龄，int类型
        double score = 98.5;    // 成绩，double类型
        char color = '红';      // 颜色，char类型，单引号
        boolean isPass = true;  // 是否及格，boolean类型
        String name = "行者";   // 姓名，String类型，双引号
        // 输出
        System.out.println("姓名：" + name);
        System.out.println("年龄：" + age);
        System.out.println("成绩：" + score);
        System.out.println("是否及格：" + isPass);
        System.out.println("喜欢的颜色：" + color);
    }
}