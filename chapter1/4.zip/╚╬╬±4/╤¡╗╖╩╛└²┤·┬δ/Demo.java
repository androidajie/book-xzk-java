public class Demo {
    public static void main(String[] args) {
        int day = 1;            // 1）初始化循环变量
        while (day <= 100) {    // 2）循环条件
            System.out.println("天天学习打卡：" + day);
            day++;              // 3）循环变量值更新
        }

    }
}

