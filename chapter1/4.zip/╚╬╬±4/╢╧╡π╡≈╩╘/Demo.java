public class Demo {
    public static void main(String[] args) {
        int i = 0;    // 在此处设置断点进行调试
        while (i < 5) {
            System.out.println("打卡：" + (i + 1));
            i++;
        }
    }
}
