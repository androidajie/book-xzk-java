public class Car {
    //颜色
    String color;
    //价格
    double price;
    //加速的方法
    void speedUp() {
        System.out.println("售价" + price + "的" + color + "汽车正在加速");
    }
}
