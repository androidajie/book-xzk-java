package com.kaikeba.xinzhike;
public class Demo {
    // 程序入口
    public static void main(String[] args) {
        String date = Tools.getFormatNow();
        System.out.println(date);
    }
}